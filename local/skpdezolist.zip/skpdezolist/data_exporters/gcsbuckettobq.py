import os
from mage_ai.settings.repo import get_repo_path
from mage_ai.io.google_cloud_storage import GoogleCloudStorage
from mage_ai.io.bigquery import BigQuery
from mage_ai.io.config import ConfigFileLoader
from pandas import DataFrame
from os import path

from google.cloud import storage
from google.oauth2 import service_account
import pandas as pd



if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


@data_exporter
def export_data_to_big_query(df: DataFrame, **kwargs) -> None:
    config_path = path.join(get_repo_path(), 'io_config.yaml')
    config_profile = 'dev'

    bucket_name = 'skp-olist-gcp'
    credentials = service_account.Credentials.from_service_account_file('/home/src/gcp.json')
    client = storage.Client(credentials=credentials)

    blobs = client.list_blobs(bucket_name)
    for blob in blobs:
        print(blob.name)

        data = GoogleCloudStorage.with_config(ConfigFileLoader(config_path, config_profile)).load(
            bucket_name,
            blob.name,
        )

        print (len(data))

        table_name , extension = os.path.splitext(blob.name)
        table_id = 'trans-array-412413.olist.' + table_name    
        
        print(table_name)
        print(table_id)

        BigQuery.with_config(ConfigFileLoader(config_path, config_profile)).export(
            data,
            table_id,
            if_exists='replace',  # Specify resolution policy if table name already exists
        )