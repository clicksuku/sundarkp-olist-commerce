import os
from kaggle.api.kaggle_api_extended import KaggleApi

import zipfile

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@data_loader
def load_data(*args, **kwargs):
    """
    Template code for loading data from any source.

    Returns:
        Anything (e.g. data frame, dictionary, array, int, str, etc.)
    """
    # Specify your data loading logic here

    path = '/home/src/data'
    os.chdir('/home/src/')

    try:
        os.mkdir(path)
        print("Folder %s created!")
    except FileExistsError:
        print("Folder %s already exists")

    api = KaggleApi()
    api.authenticate()

    api.dataset_download_files('olistbr/brazilian-ecommerce')
    api.dataset_download_files('olistbr/marketing-funnel-olist')

    with zipfile.ZipFile('/home/src/marketing-funnel-olist.zip', 'r') as zip_ref:
        zip_ref.extractall('/home/src/data/')

    with zipfile.ZipFile('/home/src/brazilian-ecommerce.zip', 'r') as zip_ref:
        zip_ref.extractall('/home/src/data/')

    try:
        os.remove('/home/src/marketing-funnel-olist.zip')
        os.remove('/home/src/brazilian-ecommerce.zip')
        print("Zips created!")
    except FileExistsError:
        print("Exception")

    

    return {}

@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
