{{
    config(
        materialized='table'
    )
}}

with sellers as (

    select * from {{ source('staging', 'olist_sellers_dataset') }}

)

select
    seller_id,
    seller_zip_code_prefix,
    seller_city,
    seller_state

from sellers

-- dbt build --select <model_name> --vars '{'is_test_run': 'false'}'
{% if var('is_test_run', default=true) %}

  limit 100

{% endif %}