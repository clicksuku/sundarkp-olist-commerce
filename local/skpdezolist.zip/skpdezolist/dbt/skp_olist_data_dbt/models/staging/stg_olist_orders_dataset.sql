{{
    config(
        materialized='table'
    )
}}

with orders as (

    select * from {{ source('staging', 'olist_orders_dataset') }}

)
select
    order_id,
    customer_id,
    order_status,
    cast(order_purchase_timestamp as timestamp) as orderPurchasedDate,
    cast(order_approved_at as timestamp) as orderApprovedDate,
    cast(order_delivered_carrier_date as timestamp) as orderCarrierPickupDate,
    cast(order_delivered_customer_date as timestamp) as orderDeliveredDate,
    cast(order_estimated_delivery_date as timestamp) as orderEstimatedDate
from orders

-- dbt build --select <model_name> --vars '{'is_test_run': 'false'}'
{% if var('is_test_run', default=true) %}

  limit 100

{% endif %}
