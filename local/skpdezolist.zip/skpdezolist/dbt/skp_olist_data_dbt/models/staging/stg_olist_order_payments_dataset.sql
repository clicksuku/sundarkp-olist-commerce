{{
    config(
        materialized='table'
    )
}}

with order_payments as (

    select * from {{ source('staging', 'olist_order_payments_dataset') }}

)
select
    order_id,
    payment_sequential,
    payment_type,
    payment_installments,
    payment_value
from order_payments