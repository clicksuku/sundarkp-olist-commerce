#!/bin/bash

touch log.txt

echo -e "Starting...... \n" >> log.txt 

cd ~

mkdir bin
mkdir gcp_mage_spark

echo -e "Created Folders. Downloading Docker-Compose \n" >> log.txt

echo -e "Updating Packages. \n" >> log.txt

sudo DEBIAN_FRONTEND=noninteractive apt-get update -y
echo -e "Done with updates. \n" >> log.txt


wget -O docker-compose https://github.com/docker/compose/releases/download/v2.24.2/docker-compose-linux-x86_64 
sudo chmod +x docker-compose
mv docker-compose ./bin

echo -e "Installed Docker Compose. \n" >> log.txt

sudo apt-get install unzip -y

mv ~/installfiles/Dockerfile ./gcp_mage_spark/
mv ~/installfiles/bashrc ./gcp_mage_spark/bashrc
mv ~/installfiles/kaggle.json ./gcp_mage_spark/
mv ~/installfiles/docker-compose.yml ./gcp_mage_spark/
mv ~/installfiles/gcp.json ./gcp_mage_spark/
mv ~/installfiles/requirements.txt ./gcp_mage_spark/
mv ~/installfiles/skpdezolist.zip ./gcp_mage_spark/

echo -e "Starting with Docker Install. \n" >> log.txt

#sudo apt-get install docker.io -y
sudo snap install docker
echo -e "Done with installing docker. \n" >> log.txt

sudo addgroup --system docker
sudo adduser $USER docker
newgrp docker
sudo snap disable docker
sudo snap enable docker

echo -e "Configured Docker to run without SUDO. \n" >> log.txt


cd gcp_mage_spark

#unzip skpdezolistpipeline.zip

echo -e "Unzipped Mage Pipeline \n" >> log.txt

sudo docker build -t mage_spark .

echo -e "Built Docker Image \n" >> log.txt

#sudo docker-compose up -d

#echo -e "Starting Docker Compose \n" >> log.txt

sudo docker run -d -t --name skp_mage_spark -e SPARK_MASTER_HOST='local' -p 6789:6789 -v $(pwd):/home/src mage_spark /app/run_app.sh mage start skp_demo_project
